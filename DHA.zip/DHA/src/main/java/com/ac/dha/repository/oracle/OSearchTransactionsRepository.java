package com.ac.dha.repository.oracle;

import com.ac.dha.repository.common.CSearchTransactionsRepository;
//@Repository(DatabaseContants.ORACLE + AbhaRepoEnums.API_CALL_EVENT_LOG_REPO)
public interface OSearchTransactionsRepository extends CSearchTransactionsRepository{

}