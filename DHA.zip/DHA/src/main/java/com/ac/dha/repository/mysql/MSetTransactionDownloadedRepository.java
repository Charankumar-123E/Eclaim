package com.ac.dha.repository.mysql;

import com.ac.dha.repository.common.CSetTransactionDownloadedRepository;
//@Repository(DatabaseContants.MYSQL + AbhaRepoEnums.API_CALL_EVENT_LOG_REPO)
public interface MSetTransactionDownloadedRepository extends CSetTransactionDownloadedRepository {

}
