package com.ac.dha.repository.postgres;

import com.ac.dha.repository.common.CSetTransactionDownloadedRepository;
//@Repository(DatabaseContants.POSTGRESQL + AbhaRepoEnums.API_CALL_EVENT_LOG_REPO)
public interface PSetTransactionDownloadedRepository extends CSetTransactionDownloadedRepository {

}

