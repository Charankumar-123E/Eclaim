package com.ac.dha.repository.postgres;

import com.ac.dha.repository.common.CPharmacyRequestRepository;

//@Repository(DatabaseContants.POSTGRESQL + AbhaRepoEnums.API_CALL_EVENT_LOG_REPO)
public interface PPharmacyRequestRepository extends CPharmacyRequestRepository {

}