package com.ac.dha.repository.common;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ac.dha.entity.PharmacyERXRequest;

public interface CPharmacyRequestRepository extends JpaRepository<PharmacyERXRequest, Long>{

}
