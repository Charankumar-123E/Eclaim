package com.ac.dha.utils;

public class EclaimRepoBaseConstant {
	public static final String CLINIC_REQUEST_REPO = "ClinicalRequestRepo";
	public static final String DOWNLOAD_TRANSACTION_FILE_REPO = "DownloadTransactionFileRepo";
	public static final String GETERX_TRANSACTION_REQUEST_REPO = "GeteRxTransactionRequestRepo";
	public static final String GETNEW_TRANSACTION_REPO = "GetNewTransactionsRepo";
	public static final String PHARMACY_REQUEST_REPO = "PharmacyRequestRepo";
	public static final String SEARCH_TRANSACTIONS_REPO = "SearchTransactionsRepo";
	public static final String SETTRANSACTION_DOWNLOAD_REPO = "SetTransactionDownloadedRepo";
	public static final String UPLOADERX_REQUEST_CLINICAL_REPO = "UploadERxRequestClinicRepo";
	public static final String UPLOADERX_REQUEST_PHARMACY_REPO = "UploadERxRequestPharmacyRepos";
}
