package com.ac.dha.repository.postgres;

import org.springframework.stereotype.Repository;

import com.ac.dha.repository.common.CGeteRxTransactionRequestRepository;

//@Repository(DatabaseContants.POSTGRESQL + AbhaRepoEnums.API_CALL_EVENT_LOG_REPO)
public interface PGeteRxTransactionRequestRepository extends CGeteRxTransactionRequestRepository {

}