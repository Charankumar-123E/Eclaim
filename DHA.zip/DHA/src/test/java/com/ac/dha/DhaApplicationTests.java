package com.ac.dha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DhaApplicationTests {

	@Test
	void contextLoads() {
	}

}
