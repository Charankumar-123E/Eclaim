//package com.ac.dha.utils;
//
//import org.springframework.stereotype.Component;
//
//@Component
//public class WebServiceEntitiesMapper {
//
//	
//}
package com.ac.dha.utils;


