package com.ac.dha.repository.postgres;

import com.ac.dha.repository.common.CUploadERxRequestClinicRepository;
//@Repository(DatabaseContants.POSTGRESQL + AbhaRepoEnums.API_CALL_EVENT_LOG_REPO)
public interface PUploadERxRequestClinicRepository extends CUploadERxRequestClinicRepository{

}
