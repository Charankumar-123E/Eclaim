package com.ac.dha.repository.oracle;

import com.ac.dha.repository.common.CGetNewTransactionsRepository;
//@Repository(DatabaseContants.ORACLE + AbhaRepoEnums.API_CALL_EVENT_LOG_REPO)
public interface OGetNewTransactionsRepository extends CGetNewTransactionsRepository{

}