package com.ac.dha.repository.oracle;

import com.ac.dha.repository.common.CGeteRxTransactionRequestRepository;
//@Repository(DatabaseContants.ORACLE + AbhaRepoEnums.API_CALL_EVENT_LOG_REPO)
public interface OGeteRxTransactionRequestRepository extends CGeteRxTransactionRequestRepository {

}
