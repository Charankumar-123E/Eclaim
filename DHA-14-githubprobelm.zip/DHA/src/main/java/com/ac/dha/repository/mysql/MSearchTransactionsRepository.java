package com.ac.dha.repository.mysql;

import com.ac.dha.repository.common.CSearchTransactionsRepository;

//@Repository(DatabaseContants.MYSQL + EclaimRepoBaseConstant.SEARCH_TRANSACTIONS_REPO)
public interface MSearchTransactionsRepository extends CSearchTransactionsRepository {

}