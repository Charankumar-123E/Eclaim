package com.ac.dha.repository.mysql;

import com.ac.dha.repository.common.CUploadERxRequestClinicRepository;
//@Repository(DatabaseContants.MYSQL + AbhaRepoEnums.API_CALL_EVENT_LOG_REPO)
public interface MUploadERxRequestClinicRepository extends CUploadERxRequestClinicRepository {

}
