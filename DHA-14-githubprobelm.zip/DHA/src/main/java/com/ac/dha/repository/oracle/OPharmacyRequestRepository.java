package com.ac.dha.repository.oracle;

import com.ac.dha.repository.common.CPharmacyRequestRepository;
//@Repository(DatabaseContants.ORACLE + AbhaRepoEnums.API_CALL_EVENT_LOG_REPO)
public interface OPharmacyRequestRepository extends CPharmacyRequestRepository {

}

