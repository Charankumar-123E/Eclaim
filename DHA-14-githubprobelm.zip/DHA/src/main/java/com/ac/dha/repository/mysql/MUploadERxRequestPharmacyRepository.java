package com.ac.dha.repository.mysql;

import com.ac.dha.repository.common.CUploadERxRequestPharmacyRepository;
//@Repository(DatabaseContants.MYSQL + AbhaRepoEnums.API_CALL_EVENT_LOG_REPO)
public interface MUploadERxRequestPharmacyRepository extends CUploadERxRequestPharmacyRepository {

}
